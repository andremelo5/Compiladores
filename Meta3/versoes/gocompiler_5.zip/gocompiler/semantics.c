#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "ast.h"
#include "semantics.h"

int semantic_errors = 0;

struct symbol_list *symbol_table;

void check_varDecl(struct node *varspec, struct symbol_list *tabela){
    struct node *id = getchild(varspec, 1);
    enum type type = category_type(getchild(varspec,0)->category);

    if(id->token==NULL){ 
        //para corrigir o problema de multiplas vardecl 
        //ao fzr o addtype o id esta como terceiro filho e nao como segundo
        //e o type nao esta como primeiro mas sim como segundo
        id = getchild(varspec, 2);
        type = category_type(getchild(varspec,1)->category);
    }
    if(search_symbol(tabela, id->token) == NULL && search_symbol(symbol_table, id->token) == NULL) {
        insert_symbol(tabela, id->token, type, varspec,false,NULL);
    } else {
        printf("Identifier %s (%d:%d) already declared\n", id->token, id->token_line, id->token_column);
        semantic_errors++;
    }

}


void check_funcBody(struct node *funcBody,struct symbol_list *scope){
    struct node_list *child = funcBody->children;
    while ((child=child->next) != NULL) {
        struct node *child_node = child->node;
        if(child_node->category==aux){
            check_funcBody(child_node,scope);
        }
        // varDecl
        if (child_node->category == VarDecl) {
            check_varDecl(child_node, scope); 
        }
    }
}






void check_funcParams(struct node *funcParams,struct symbol_list *scope,char *string_params){
    //FuncParams e o parameters da gramatica so podem ser chamadis pelo funcHeader
    //tem de ser guardados na tabela global os types 
    // na tabela da funcao tem de ficar os ids e os types

    //vai buscar todos os types dos parametros e junta-os numa string
    //vai ao funcParams e dentro dele percorre todos os nos ParamDecl para tirar o type
    

    struct node_list *paramDecl= funcParams->children;
    while((paramDecl=paramDecl->next)!=NULL){
        struct node *paramDecl_node = paramDecl->node;

        if(paramDecl_node->category==aux){
            check_funcParams(paramDecl_node,scope,string_params);
        } else{
            struct node *id = getchild(paramDecl_node,1);
            enum type type = category_type(getchild(paramDecl_node,0)->category);
            strcat(string_params, type_name(type));

            if(search_symbol(symbol_table, id->token) == NULL && search_symbol(scope, id->token) == NULL) {
                insert_symbol(scope, id->token, type, paramDecl_node,false,NULL);
            } else {
                printf("Identifier %s (%d:%d) already declared\n", id->token, id->token_line, id->token_column);
                semantic_errors++;
            }
        }

        if (paramDecl->next != NULL) {
            strcat(string_params, ",");
        }
    }



}



void check_funcDecl(struct node *funcdecl,struct symbol_list *tabela){
    struct node *funcHeader = getchild(funcdecl,0);
    struct node *funcBody = getchild(funcdecl,1);

    struct node *id = getchild(funcHeader, 0);
    enum type type = category_type(getchild(funcHeader,1)->category);



    //Cria uma nova tabela para a funcao e adiciona como filha da global
    struct symbol_list *scope = (struct symbol_list *) malloc(sizeof(struct symbol_list));
    scope->identifier = strdup(id->token);
    scope->next = NULL;
    scope->children = NULL;
    scope->is_func = true;
    scope->is_param = false;
    scope->lista_params = NULL;


    if(symbol_table->children == NULL) {
        symbol_table->children = scope;
    } else {
        struct symbol_list *child = symbol_table->children;
        while(child->next != NULL)
            child = child->next;
        child->next = scope;
    }

    insert_symbol(scope,"return",type,funcdecl,false,NULL); //martelar o return para cada tabela de cada funcao

    //verificar o funcParams
    char string_params[256]="";
    if(type==no_type){ //tive de adicionar isto pq quando nao ha type na funcao o nº do child muda
        check_funcParams(getchild(funcHeader,1),scope,string_params);
    }else{
        check_funcParams(getchild(funcHeader,2),scope,string_params);
    }
    
    scope->lista_params = strdup(string_params);


    if(search_symbol(tabela, id->token) == NULL) {
        insert_symbol(tabela, id->token, type, funcdecl,true,string_params);
    } else {
        printf("Identifier %s (%d:%d) already declared\n", id->token, id->token_line, id->token_column);
        semantic_errors++;
    }


    //verificar o funcBody
    check_funcBody(funcBody,scope);

    

}

// semantic analysis begins here, with the AST root node
int check_program(struct node *program) {
    if(symbol_table==NULL){
        symbol_table = (struct symbol_list *) malloc(sizeof(struct symbol_list));
        symbol_table->next = NULL;
        symbol_table->identifier=strdup("Global");
        symbol_table->is_func=true;
        symbol_table->is_param=false;
        symbol_table->lista_params=NULL;
    }
    struct node_list *child = program->children;
    while((child = child->next) != NULL)
        if(child->node->category==VarDecl){
            check_varDecl(child->node,symbol_table);
        }else if(child->node->category==FuncDecl){
            check_funcDecl(child->node,symbol_table);
        }else if(child->node->category==aux){
            check_program(child->node);
        }
    return semantic_errors;
}

// insert a new symbol in the list, unless it is already there
struct symbol_list *insert_symbol(struct symbol_list *table, char *identifier, enum type type, struct node *node,bool is_func,char *lista_params) {
    struct symbol_list *new = (struct symbol_list *) malloc(sizeof(struct symbol_list));
    new->identifier = strdup(identifier);
    new->type = type;
    new->node = node;
    new->next = NULL;
    new->is_func=is_func;
    if (lista_params == NULL) {
        new->lista_params = strdup("()");
    } else {
        new->lista_params = strdup(lista_params);
    }
    struct symbol_list *symbol = table;
    while(symbol != NULL) {
        if(symbol->next == NULL) {
            symbol->next = new;    /* insert new symbol at the tail of the list */
            break;
        } else if(strcmp(symbol->next->identifier, identifier) == 0) {
            free(new);
            return NULL;           /* return NULL if symbol is already inserted */
        }
        symbol = symbol->next;
    }
    return new;
}

// look up a symbol by its identifier
struct symbol_list *search_symbol(struct symbol_list *table, char *identifier) {
    struct symbol_list *symbol;
    for(symbol = table->next; symbol != NULL; symbol = symbol->next)
        if(strcmp(symbol->identifier, identifier) == 0)
            return symbol;
    return NULL;
}

void show_symbol_table(struct symbol_list *tabela) {
    if(tabela==NULL||tabela->identifier == NULL||tabela->is_func==false){
        return;
    }
    printf("===== %s Symbol Table =====\n",tabela->identifier);

    struct symbol_list *symbol;
    for(symbol = tabela->next; symbol != NULL; symbol = symbol->next){
        if (symbol->is_func) {
            printf("%s\t(%s)\t%s\n", symbol->identifier, symbol->lista_params, type_name(symbol->type));
        } else {
            printf("%s\t%s\n", symbol->identifier, type_name(symbol->type));
        }
    }
    printf("\n");

    struct symbol_list *child = tabela->children;
    while(child != NULL) {
        show_symbol_table(child);
        child = child->next;
    }
}







