#ifndef _SEMANTICS_H
#define _SEMANTICS_H

#include "ast.h"

int check_program(struct node *program);

struct symbol_list {
	char *identifier;				//nome da variavel ou funcao
	enum type type;
	struct node *node;
	struct symbol_list *next;
	struct symbol_list *children;	//lista de tabelas de cada funcao declarada, ficam todas como filhas da global
	bool is_func;					//flag para verificar se e uma funcao para depois dar um print diferente
	char *lista_params;				//guarda os tipos dos parametros da funcao

};

struct symbol_list *insert_symbol(struct symbol_list *table, char *identifier, enum type type, struct node *node,bool is_func,char *lista_params);
struct symbol_list *search_symbol(struct symbol_list *symbol_table, char *identifier);
void show_symbol_table(struct symbol_list *tabela);

#endif
