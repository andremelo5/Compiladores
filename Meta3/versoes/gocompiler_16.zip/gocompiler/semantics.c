#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "ast.h"
#include "semantics.h"

int semantic_errors = 0;

struct symbol_list *symbol_table;
int count=0;

void check_varDecl(struct node *varspec, struct symbol_list *tabela){
    struct node *id = getchild(varspec, 1);
    enum type type = category_type(getchild(varspec,0)->category);

    if(id->token==NULL){ 
        //para corrigir o problema de multiplas vardecl 
        //ao fzr o addtype o id esta como terceiro filho e nao como segundo
        //e o type nao esta como primeiro mas sim como segundo
        id = getchild(varspec, 2);
        type = category_type(getchild(varspec,1)->category);
    }
    if(search_symbol(symbol_table, id->token) == NULL && search_symbol(tabela, id->token) == NULL ) {
        insert_symbol(tabela, id->token, type, varspec,false,NULL);
    }// else if(search_symbol(symbol_table, id->token) != NULL && search_symbol(symbol_table, id->token)->type != type){
        //    insert_symbol(tabela, id->token, type, varspec,false,NULL);
    //}
    else if(search_symbol(symbol_table, id->token) != NULL && search_symbol(tabela, id->token) == NULL && search_symbol(symbol_table, id->token)->type != type){
            insert_symbol(tabela, id->token, type, varspec,false,NULL);
    }else {
        printf("Line %d, column %d: Symbol %s already defined\n", id->token_line, id->token_column,id->token);
        semantic_errors++;
    }

}

void check_expr(struct node *expr,struct symbol_list *scope){
    struct node *expr1 = (struct node *) malloc(sizeof(struct node));
    struct node *expr2 = (struct node *) malloc(sizeof(struct node));
    struct node *id = (struct node *) malloc(sizeof(struct node));
    struct node *aux = (struct node *) malloc(sizeof(struct node));
    struct node_list *child = (struct node_list *) malloc(sizeof(struct node_list));
    struct node *child_node = (struct node *) malloc(sizeof(struct node));
    switch(expr->category){
        case Identifier:
            if(search_symbol(scope, expr->token) == NULL && search_symbol(symbol_table, expr->token) == NULL) {
                printf("Line %d, column %d: Cannot find symbol %s \n", expr->token_line, expr->token_column, expr->token);
                semantic_errors++;
            }else{
                //necessario verificar na local e na global antes de atribuir o type
                if(search_symbol(scope, expr->token)!=NULL){
                    expr->type = search_symbol(scope, expr->token)->type;
                }else if(search_symbol(symbol_table, expr->token)!=NULL){
                    expr->type = search_symbol(symbol_table, expr->token)->type;
                } 
                expr->is_expr=1;
            }
            break;

        case Natural:
            expr->type=int_type;
            expr->is_expr=1;
            break;

        case Decimal:
            expr->type=float32_type;
            expr->is_expr=1;
            break;

        case Or:
        case And:
            expr1=getchild(expr,0);
            expr2=getchild(expr,1);
            check_expr(expr1,scope);
            check_expr(expr2,scope);
            if(expr1->type==expr2->type && expr1->type==bool_type){
                expr->type=bool_type;
                expr->is_expr=1;
                expr1->is_expr=1;
                expr2->is_expr=1;
            }else{
                printf("Line %d, column %d: Operator && cannot be applied to types %s, %s\n",expr->token_line, expr->token_column,type_name(expr1->type),type_name(expr2->type));
                semantic_errors++;
            }
            break;
        case Le:
        case Ge:
        case Lt:
        case Gt:
            expr1=getchild(expr,0);
            expr2=getchild(expr,1);
            check_expr(expr1,scope);
            check_expr(expr2,scope);
            if(expr1->type!=expr2->type||expr1->type==string_type||expr1->type==no_type||expr1->type==bool_type){
                printf("Line %d, column %d: Operator > cannot be applied to types %s, %s\n",expr->token_line, expr->token_column,type_name(expr1->type),type_name(expr2->type));
                semantic_errors++;
            }else{
                expr->type=bool_type;
                expr->is_expr=1;
                expr1->is_expr=1;
                expr2->is_expr=1;
            }
            break;
        case Eq:
        case Ne:
            expr1=getchild(expr,0);
            expr2=getchild(expr,1);
            check_expr(expr1,scope);
            check_expr(expr2,scope);
            if(expr1->type!=expr2->type||expr1->type==no_type){
                printf("Line %d, column %d: Operator != cannot be applied to types %s, %s\n",expr->token_line, expr->token_column,type_name(expr1->type),type_name(expr2->type));
                semantic_errors++;
            }else{
                expr->type=bool_type;
                expr->is_expr=1;
                expr1->is_expr=1;
                expr2->is_expr=1;
            }
            break;
        
        case Add:
        case Sub:
        case Mul:
        case Div:
        case Mod:
            expr1=getchild(expr,0);
            expr2=getchild(expr,1);
            check_expr(expr1,scope);
            check_expr(expr2,scope);
            if(expr1->type!=expr2->type||expr1->type==string_type||expr1->type==no_type||expr1->type==bool_type){
                printf("Line %d, column %d: Operator %% cannot be applied to types %s, %s\n",expr->token_line, expr->token_column,type_name(expr1->type),type_name(expr2->type));
                semantic_errors++;
            }else{
                expr->type=expr1->type;
                expr->is_expr=1;
                expr1->is_expr=1;
                expr2->is_expr=1;
            }
            break;
        case Not:
            expr1=getchild(expr,0);
            check_expr(expr1,scope);
            if(expr1->type==bool_type){
                expr->type=expr1->type;
                expr->is_expr=1;
                expr1->is_expr=1;
            }else{
                printf("Line %d, column %d: Operator ! cannot be applied to type %s\n",expr->token_line, expr->token_column,type_name(expr1->type));
                semantic_errors++;
            }
            break;
        case Minus:
        case Plus:
            expr1=getchild(expr,0);
            check_expr(expr1,scope);
            if(expr1->type==string_type||expr1->type==no_type||expr1->type==bool_type){
                printf("Line %d, column %d: Operator + cannot be applied to type %s\n",expr->token_line, expr->token_column,type_name(expr1->type));
                semantic_errors++;
            }else{
                expr->type=expr1->type;
                expr->is_expr=1;
                expr1->is_expr=1;
            }
            break;

        case Call:
            id=getchild(expr,0); //o id fica com os types dos parametros que passa na chamada e apresenta a lista de todos os tipos passados
            char lista_types_call[256]="";

                    if (getchild(expr,1)!=NULL){ //verifica o primeiro expr
                        check_expr(getchild(expr,1),scope);
                        strcat(lista_types_call, type_name(getchild(expr,1)->type));
                        if (getchild(expr,2)!=NULL){
                            aux=getchild(expr,2);
                            child = aux->children; //aux pode ter mais do que um filho expr
                            while ((child=child->next) != NULL) {
                                child_node = child->node;
                                check_expr(child_node,scope);
                                strcat(lista_types_call, ",");
                                strcat(lista_types_call, type_name(child_node->type));
                            }
                        }
                    }
            if((search_symbol(scope, id->token) == NULL && search_symbol(symbol_table, id->token) == NULL) || search_symbol(symbol_table, id->token)->node->category != FuncDecl ) { //verificar se a funcao existe
                printf("Line %d, column %d: Cannot find symbol %s(%s)\n", id->token_line, id->token_column, id->token,lista_types_call);
                semantic_errors++;
            }else{ 
                //countblocks foi uma funcao criada na meta2 e que permite contar o numero de filhos ignorando aux e -1 para ignorar o nome da funcao
                int n_argumentos_call = countblocks(expr)-1; //n parametros na chamada
                int count_n_parametros = search_symbol(symbol_table, id->token)->node->count_n_parametros;//n parametros da funcao


                //verificar o numero de parametros na chamada da funcao 
                if(n_argumentos_call!=count_n_parametros){
                    printf("Line %d, column %d: Cannot find symbol %s(%s)\n", id->token_line, id->token_column, id->token,lista_types_call);
                    semantic_errors++;
                }else{
                    //verificar o id, atribuir o type do id a call, dzr q e uma expr e uma func
                    check_expr(id,scope);
                    expr->type=id->type;
                    expr->is_expr=1;
                    id->is_func=1;

                    //lista de tipos dos argumentos da funcao
                    char *lista_types=search_symbol(symbol_table, id->token)->lista_params;

                    //lista de tipos dos argumentos da chamada da funcao
                    char lista_types_call[256]="";

                    if (getchild(expr,1)!=NULL){ //verifica o primeiro expr
                        check_expr(getchild(expr,1),scope);
                        strcat(lista_types_call, type_name(getchild(expr,1)->type));
                        if (getchild(expr,2)!=NULL){
                            aux=getchild(expr,2);
                            child = aux->children; //aux pode ter mais do que um filho expr
                            while ((child=child->next) != NULL) {
                                child_node = child->node;
                                check_expr(child_node,scope);
                                strcat(lista_types_call, ",");
                                strcat(lista_types_call, type_name(child_node->type));
                            }
                        }
                    }

                    if(strcmp(lista_types_call,lista_types)!=0){
                        printf("Line %d, column %d: Cannot find symbol %s(%s)\n", id->token_line, id->token_column, id->token,lista_types_call);
                        semantic_errors++;
                       // printf("Tipos da funcao errados: \n%s\n%s\n",lista_types_call,lista_types);
                    }else{
                        id->lista_tipos = malloc(strlen(lista_types_call) + 1); // Aloca memória suficiente
                        if (id->lista_tipos != NULL) {
                            strcpy(id->lista_tipos, lista_types_call); // Copia a string para a memória alocada
                        }
                    }

                    //tenho de ir buscar a lista de parametros(tipos) da funcao e compara-la com o que esta a ser chamado 
                    // se os tipo estiverem todos bem e na ordem certa, tenho de adicioanar ao id a lista de parametros(tipos)
                    // depois no print tenho de alterar a logica para mostar a lista de parametros(tipos) e nao apenas o tipo
                    

                }
                
            }

            break;
              
        default:
            break;
    }   

}    

void check_statements(struct node *statement,struct symbol_list *scope){
    struct node *id = (struct node *) malloc(sizeof(struct node));
    struct node *expr = (struct node *) malloc(sizeof(struct node));
    struct node *aux = (struct node *) malloc(sizeof(struct node));
    struct node_list *child = (struct node_list *) malloc(sizeof(struct node_list));
    struct node *child_node = (struct node *) malloc(sizeof(struct node));

    switch(statement->category){
        case Assign:
            id = getchild(statement,0);
            expr = getchild(statement,1);
            check_expr(id,scope);
            check_expr(expr,scope);
            if(expr->type!=id->type){
                if(expr->type==no_type){expr->type=undef;}
                printf("Line %d, column %d: Operator = cannot be applied to types %s, %s\n",statement->token_line, statement->token_column,type_name(id->type),type_name(expr->type));
                semantic_errors++;
                
            }else{
                statement->type=expr->type;
                statement->is_expr=1;
            }
            break;

        case If:
            id = getchild(statement,0);
            check_expr(id,scope);
            check_statements(getchild(statement,1),scope); //primeiro block
            check_statements(getchild(statement,2),scope); //segundo block


        case For:
            if (getchild(statement,0)->category==Block){
                check_statements(getchild(statement,0),scope);
            }else{
                check_expr(getchild(statement,0),scope);
                check_statements(getchild(statement,1),scope);
            }

            break;

        case Block:
            if (getchild(statement,0)!=NULL){
                aux=getchild(statement,0);
                child = aux->children; //aux pode ter mais do que um filho expr
                while ((child=child->next) != NULL) {
                    child_node = child->node;
                    check_statements(child_node,scope);
                }
            }
            break;
        case Return:
            if (getchild(statement,0)!=NULL){
                expr=getchild(statement,0);
                check_expr(expr,scope);
                //verificar se o tipo da expressao e igual ao da funcao
                //ir ao no da funcao e tirar o type
                //scope->identifier --> vai buscar o no com este nome e dps a partir dele tiro o tipo
                if(search_symbol(symbol_table, scope->identifier)->type == expr->type){
                    statement->type=expr->type;
                }else{
                    printf("Line %d, column %d: Incompatible type %s in return statement\n",statement->token_line, expr->token_column,type_name(expr->type));
                    semantic_errors++;
                }
            }else{ //pode nao ter expr por isso o type tem de ser no_type
                if(search_symbol(symbol_table, scope->identifier)->type == no_type){
                    statement->type=no_type;
                }else{
                    printf("Line %d, column %d: Incompatible type %s in return statement\n",statement->token_line, statement->token_column,type_name(no_type));
                    semantic_errors++;
                }
            }
            break;

        case Call:
            check_expr(statement,scope);
            break;

        case ParseArgs:
            id=getchild(statement,0);
            expr=getchild(statement,1);
            check_expr(id,scope);
            check_expr(expr,scope);
            if(expr->type!=id->type){
                printf("Line %d, column %d: Operator %s cannot be applied to types %s, %s\n",statement->token_line, statement->token_column,id->token,type_name(id->type),type_name(expr->type));
                semantic_errors++;
            }else{
                statement->type=expr->type;
                statement->is_expr=1;
            }
            break;

        case Print:
            //print nao precisa de imprimir o tipo
            if (getchild(statement,0)->category==StrLit){
                statement->type=string_type;
            }else{
                expr=getchild(statement,0);
                check_expr(expr,scope);
                statement->type=expr->type;
            }
            break;

        default:
            break;
    }
}


void check_funcBody(struct node *funcBody,struct symbol_list *scope){
    struct node_list *child = funcBody->children;
    while ((child=child->next) != NULL) {
        struct node *child_node = child->node;
        //Nos aux
        if(child_node->category==aux){
            check_funcBody(child_node,scope);
        }
        // varDecl
        else if (child_node->category == VarDecl) {
            check_varDecl(child_node, scope); 
        }
        //Statements
        else{
            check_statements(child_node,scope);
        }   
    }
}






int check_funcParams(struct node *funcParams,struct symbol_list *scope,char *string_params,int *count_n_parametros){
    //FuncParams e o parameters da gramatica so podem ser chamadis pelo funcHeader
    //tem de ser guardados na tabela global os types 
    // na tabela da funcao tem de ficar os ids e os types

    //vai buscar todos os types dos parametros e junta-os numa string
    //vai ao funcParams e dentro dele percorre todos os nos ParamDecl para tirar o type
    
    struct node_list *paramDecl= funcParams->children;
    while((paramDecl=paramDecl->next)!=NULL){
        struct node *paramDecl_node = paramDecl->node;

        if(paramDecl_node->category==aux){
            check_funcParams(paramDecl_node,scope,string_params,count_n_parametros);
        } else{
            struct node *id = getchild(paramDecl_node,1);
            enum type type = category_type(getchild(paramDecl_node,0)->category);
            strcat(string_params, type_name(type));

            if(search_symbol(symbol_table, id->token) == NULL && search_symbol(scope, id->token) == NULL ){
                insert_symbol(scope, id->token, type, paramDecl_node,false,NULL);
                paramDecl_node->is_param=1;
                (*count_n_parametros)++;
            } else {
                printf("Line %d, column %d: Symbol %s already defined\n", id->token_line, id->token_column,id->token);
                semantic_errors++;
            }
        }

        if (paramDecl->next != NULL) {
            strcat(string_params, ",");
        }
    }
    return *count_n_parametros;
}



void check_funcDecl(struct node *funcdecl,struct symbol_list *tabela){
    struct node *funcHeader = getchild(funcdecl,0);

    struct node *id = getchild(funcHeader, 0);
    enum type type = category_type(getchild(funcHeader,1)->category);


    //Cria uma nova tabela para a funcao e adiciona como filha da global
    struct symbol_list *scope = (struct symbol_list *) malloc(sizeof(struct symbol_list));
    scope->identifier = strdup(id->token);
    scope->next = NULL;
    scope->children = NULL;
    scope->is_func = true;
    scope->lista_params = NULL;


    insert_symbol(scope,"return",type,funcdecl,false,NULL); //martelar o return para cada tabela de cada funcao


    //verificar o funcParams
    int count_params=0;
    char string_params[256]="";
    if(type==no_type){ //tive de adicionar isto pq quando nao ha type na funcao o nº do child muda
        count_params=check_funcParams(getchild(funcHeader,1),scope,string_params,&count_params);
    }else{
        count_params=check_funcParams(getchild(funcHeader,2),scope,string_params,&count_params);
    }
    
    scope->lista_params = strdup(string_params);


    if(search_symbol(symbol_table, id->token) == NULL) {
        insert_symbol(symbol_table, id->token, type, funcdecl,true,string_params);
        funcdecl->count_n_parametros=count_params;
    } else {
        printf("Line %d, column %d: Symbol %s already defined\n", id->token_line, id->token_column,id->token);
        semantic_errors++;
    }


    if(symbol_table->children == NULL) {
        symbol_table->children = scope;
    } else {
        struct symbol_list *child = symbol_table->children;
        while(child->children != NULL){
            child = child->children;
        }
        child->children = scope;
    }
    

}

int check_program2(struct node *program) {

    struct node_list *child = program->children;

    while ((child = child->next) != NULL) {
        if (child->node->category == FuncDecl) {
            struct node *funcHeader = getchild(child->node,0);
            struct node *funcBody = getchild(child->node, 1);
            struct node *id = getchild(funcHeader, 0);

            struct symbol_list *scope=NULL;
            struct symbol_list *child_table=symbol_table->children;

            while(child_table != NULL){
                if(child_table->is_func==true){
                    if(strcmp(child_table->identifier,id->token)==0){
                        scope=child_table;
                        break;
                    }
                }
                child_table = child_table->next;
            }
            
            if(scope!=NULL){
                printf("%s:%s\n",id->token,scope->identifier);
                check_funcBody(funcBody,scope);
            }
            
        }else if(child->node->category==aux){
            check_program2(child->node);
        }
    }

    return semantic_errors;
}

// semantic analysis begins here, with the AST root node
int check_program(struct node *program) {
    //Cria a tabela global
    if(symbol_table==NULL){
        symbol_table = (struct symbol_list *) malloc(sizeof(struct symbol_list));
        symbol_table->next = NULL;
        symbol_table->identifier=strdup("Global");
        symbol_table->is_func=true;
        symbol_table->lista_params=NULL;
        symbol_table->children=NULL;
    }

    //cria as tabelas para todas as funcoes e adiciona tds as cariaveis as tabelas
    struct node_list *child = program->children;
    while((child = child->next) != NULL){
        if(child->node->category==VarDecl){
            check_varDecl(child->node,symbol_table);
        }else if(child->node->category==FuncDecl){
            check_funcDecl(child->node,symbol_table);
        }else if(child->node->category==aux){
            check_program(child->node);
        }
    }

    //Agr que todas as tabelas estao criadas vai verificar o funcbody de cada funcao
    check_program2(program);

    return semantic_errors;
}

// insert a new symbol in the list, unless it is already there
struct symbol_list *insert_symbol(struct symbol_list *table, char *identifier, enum type type, struct node *node,bool is_func,char *lista_params) {
    struct symbol_list *new = (struct symbol_list *) malloc(sizeof(struct symbol_list));
    new->identifier = strdup(identifier);
    new->type = type;
    new->node = node;
    new->next = NULL;
    new->is_func=is_func;
    new->children=NULL;
    if (lista_params == NULL) {
        new->lista_params = strdup("");
    } else {
        new->lista_params = strdup(lista_params);
    }
    struct symbol_list *symbol = table;
    while(symbol != NULL) {
        if(symbol->next == NULL) {
            symbol->next = new;    /* insert new symbol at the tail of the list */
            break;
        } else if(strcmp(symbol->next->identifier, identifier) == 0) {
            free(new);
            return NULL;           /* return NULL if symbol is already inserted */
        }
        symbol = symbol->next;
    }
    return new;
}

// look up a symbol by its identifier
struct symbol_list *search_symbol(struct symbol_list *table, char *identifier) {
    struct symbol_list *symbol;
    for(symbol = table->next; symbol != NULL; symbol = symbol->next)
        if(strcmp(symbol->identifier, identifier) == 0)
            return symbol;
    return NULL;
}

void show_symbol_table(struct symbol_list *tabela) {
    if(tabela->is_func==true){

        if(strcmp(tabela->identifier,"Global")==0){
            printf("===== %s Symbol Table =====\n",tabela->identifier);
        } else{
            printf("===== Function %s(%s) Symbol Table =====\n",tabela->identifier,tabela->lista_params);
        }

        struct symbol_list *symbol;
        for(symbol = tabela->next; symbol != NULL; symbol = symbol->next){
            if (symbol->is_func) {
                printf("%s\t(%s)\t%s\n", symbol->identifier, symbol->lista_params, type_name(symbol->type));
            }else if(symbol->node->is_param==1){
                printf("%s\t%s\t%s\tparam\n", symbol->identifier, symbol->lista_params,type_name(symbol->type));
            } else {
                printf("%s\t%s\t%s\n", symbol->identifier, symbol->lista_params,type_name(symbol->type));
            }
        }
        printf("\n");
    }
    struct symbol_list *child = tabela->children;
    while(child != NULL) {
        show_symbol_table(child);
        child = child->next;
    }
}







